
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package ewewukek.antiqueshotgun.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.enchantment.Enchantment;

import ewewukek.antiqueshotgun.enchantment.BruteEnchantment;
import ewewukek.antiqueshotgun.AntiqueshotgunMod;

public class AntiqueshotgunModEnchantments {
	public static final DeferredRegister<Enchantment> REGISTRY = DeferredRegister.create(ForgeRegistries.ENCHANTMENTS, AntiqueshotgunMod.MODID);
	public static final RegistryObject<Enchantment> BRUTE = REGISTRY.register("brute", () -> new BruteEnchantment());
}
