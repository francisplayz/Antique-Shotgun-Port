
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package ewewukek.antiqueshotgun.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.Item;

import ewewukek.antiqueshotgun.item.SlugAmmoItem;
import ewewukek.antiqueshotgun.item.ShotgunItem;
import ewewukek.antiqueshotgun.item.SawdOffShotgunItem;
import ewewukek.antiqueshotgun.item.RubberAmmoItem;
import ewewukek.antiqueshotgun.item.HandmadeShotgunItem;
import ewewukek.antiqueshotgun.item.HandmadeAmmoItem;
import ewewukek.antiqueshotgun.item.BuckshotShellItem;
import ewewukek.antiqueshotgun.item.AntiqueShotgunItem;
import ewewukek.antiqueshotgun.item.AmmoItem;
import ewewukek.antiqueshotgun.AntiqueshotgunMod;

public class AntiqueshotgunModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, AntiqueshotgunMod.MODID);
	public static final RegistryObject<Item> BUCKSHOT_SHELL = REGISTRY.register("buckshot_shell", () -> new BuckshotShellItem());
	public static final RegistryObject<Item> ANTIQUE_SHOTGUN = REGISTRY.register("antique_shotgun", () -> new AntiqueShotgunItem());
	public static final RegistryObject<Item> HANDMADE_AMMO = REGISTRY.register("handmade_ammo", () -> new HandmadeAmmoItem());
	public static final RegistryObject<Item> HANDMADE_SHOTGUN = REGISTRY.register("handmade_shotgun", () -> new HandmadeShotgunItem());
	public static final RegistryObject<Item> AMMO = REGISTRY.register("ammo", () -> new AmmoItem());
	public static final RegistryObject<Item> RUBBER_AMMO = REGISTRY.register("rubber_ammo", () -> new RubberAmmoItem());
	public static final RegistryObject<Item> SAWD_OFF_SHOTGUN = REGISTRY.register("sawd_off_shotgun", () -> new SawdOffShotgunItem());
	public static final RegistryObject<Item> SHOTGUN = REGISTRY.register("shotgun", () -> new ShotgunItem());
	public static final RegistryObject<Item> SLUG_AMMO = REGISTRY.register("slug_ammo", () -> new SlugAmmoItem());
	// Start of user code block custom items
	// End of user code block custom items
}
