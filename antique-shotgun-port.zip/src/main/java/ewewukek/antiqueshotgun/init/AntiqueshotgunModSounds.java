
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package ewewukek.antiqueshotgun.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;

import ewewukek.antiqueshotgun.AntiqueshotgunMod;

public class AntiqueshotgunModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, AntiqueshotgunMod.MODID);
	public static final RegistryObject<SoundEvent> BULLET_SHOT = REGISTRY.register("bullet.shot", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("antiqueshotgun", "bullet.shot")));
}
