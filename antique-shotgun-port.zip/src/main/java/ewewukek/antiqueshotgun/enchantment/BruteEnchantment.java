
package ewewukek.antiqueshotgun.enchantment;

import net.minecraft.world.item.enchantment.EnchantmentCategory;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.EquipmentSlot;

import ewewukek.antiqueshotgun.init.AntiqueshotgunModItems;

public class BruteEnchantment extends Enchantment {
	private static final EnchantmentCategory ENCHANTMENT_CATEGORY = EnchantmentCategory.create("antiqueshotgun_brute", item -> Ingredient.of(new ItemStack(AntiqueshotgunModItems.ANTIQUE_SHOTGUN.get())).test(new ItemStack(item)));

	public BruteEnchantment() {
		super(Enchantment.Rarity.COMMON, ENCHANTMENT_CATEGORY, EquipmentSlot.values());
	}

	@Override
	public int getMinCost(int level) {
		return 1 + level * 10;
	}

	@Override
	public int getMaxCost(int level) {
		return 6 + level * 10;
	}

	@Override
	public int getMaxLevel() {
		return 4;
	}

	@Override
	public boolean isTreasureOnly() {
		return true;
	}
}
